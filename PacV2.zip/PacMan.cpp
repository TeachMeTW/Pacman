#include "Pac.h" // header

using namespace std;

int main() // main file
{
	Pac one; // pac class | object 
	return 0;
}

